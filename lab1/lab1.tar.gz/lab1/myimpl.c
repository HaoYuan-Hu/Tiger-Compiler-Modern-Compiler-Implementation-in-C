#include "prog1.h"

int maxargs(A_stm stm)
{
	//TODO: put your code here.
	return 0;
}

void interp(A_stm stm)
{
	//TODO: put your code here.
}
